# Build the Android APK

This repository includes an Android Studio wrapper project, but the APK has not been compiled in this environment (Android SDK/Gradle are not installed here).

1. Install Android Studio on a computer.
2. Open the `android` folder in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Android Studio will show the generated APK location, usually `android/app/build/outputs/apk/debug/app-debug.apk`.

The app shell is bundled in `app/src/main/assets`. PineTS and Lightweight Charts are loaded from esm.sh, so internet access is required for their first load and updates.
