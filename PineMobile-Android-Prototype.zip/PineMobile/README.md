# PineMobile — Android-friendly Pine Script chart prototype

This is a first runnable prototype, not a TradingView clone and not a compiled APK.

## Features in this prototype
- Mobile-first chart using TradingView Lightweight Charts.
- PineTS runtime loaded in-browser from esm.sh.
- Pine v5/v6 editor; add multiple scripts; remove scripts; save/load `.pine` text.
- CSV OHLCV import for historical XAUUSD or other symbols.
- Bar Replay: one-bar forward, one-bar backward, jump to first visible bar, autoplay, pause, speed selection, and seek slider.
- Replay recalculates scripts against only the visible prefix of bars, so future bars are not passed to the script.
- Demo candles are synthetic and are clearly not real gold prices.

## Run on Android
1. Upload this folder to a static HTTPS host (GitHub Pages, Netlify, Cloudflare Pages, etc.).
2. Open its HTTPS address in Chrome on Android.
3. Chrome menu → Add to Home screen / Install app.

The app uses CDN modules for `pinets` and `lightweight-charts`, so the first load requires internet. The service worker caches the app shell; third-party modules may still need network access after cache expiry.

## Importing data
CSV header must include `time,open,high,low,close` and optionally `volume`. `time` may be ISO date/time or Unix seconds/milliseconds. Bars are sorted oldest to newest. The timeframe selector is a UI placeholder; CSV candles are displayed at their original spacing until timeframe aggregation is implemented.

## Important limitations
- No live XAUUSD feed or broker connection is included. Import a broker-exported CSV.
- PineTS is an independent runtime, not TradingView's proprietary runtime. Pine v6 support is experimental and some language features, drawing objects, tables, alerts, broker emulator behavior, and built-ins may differ or be unsupported.
- This prototype renders numeric `plot()` series as lines. It does not yet render all Pine visuals such as `plotshape`, `label`, `box`, `line`, `fill`, tables, or strategy trade markers.
- Every replay step reruns scripts on the visible history. This prioritizes correctness against future-data leakage over speed; large scripts/data sets may be slow.
- No trading or order execution.

## License notes
PineTS is AGPL-3.0 or commercial dual-licensed. Review its terms before distributing a closed-source application. Lightweight Charts requires attribution to TradingView and the notice/link specified in its documentation.

## References
- https://github.com/LuxAlgo/PineTS
- https://github.com/tradingview/lightweight-charts
